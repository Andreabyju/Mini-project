<?php
session_start();
require_once "connect.php";

// Initialize variables
$daycarePlans = [
    'dog' => [
        'half_day' => ['name' => 'Half Day Care', 'price' => 399, 'hours' => 5],
        'full_day' => ['name' => 'Full Day Care', 'price' => 699, 'hours' => 10],
        'weekly' => ['name' => 'Weekly Package (5 days)', 'price' => 2999, 'days' => 5],
        'monthly' => ['name' => 'Monthly Package (20 days)', 'price' => 9999, 'days' => 20],
    ],
    'cat' => [
        'half_day' => ['name' => 'Half Day Care', 'price' => 349, 'hours' => 5],
        'full_day' => ['name' => 'Full Day Care', 'price' => 599, 'hours' => 10],
        'weekly' => ['name' => 'Weekly Package (5 days)', 'price' => 2499, 'days' => 5],
        'monthly' => ['name' => 'Monthly Package (20 days)', 'price' => 8999, 'days' => 20],
    ]
];

$additionalServices = [
    'special_diet' => ['name' => 'Special Diet Plan', 'price' => 149],
    'training' => ['name' => 'Basic Training Session', 'price' => 299],
    'play_time' => ['name' => 'Extra Play Time', 'price' => 199],
    'grooming' => ['name' => 'Basic Grooming', 'price' => 349],
    'pickup' => ['name' => 'Pickup & Drop Service', 'price' => 249]
];

$errorMsg = '';
$successMsg = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_daycare'])) {
    // Validate inputs
    $petType = $_POST['pet_type'] ?? '';
    $planType = $_POST['plan_type'] ?? '';
    $startDate = $_POST['start_date'] ?? '';
    $additionalServicesList = isset($_POST['additional_services']) ? $_POST['additional_services'] : [];
    $petName = $_POST['pet_name'] ?? '';
    $petBreed = $_POST['pet_breed'] ?? '';
    $petAge = $_POST['pet_age'] ?? '';
    $petWeight = $_POST['pet_weight'] ?? '';
    $ownerName = $_POST['owner_name'] ?? '';
    $ownerEmail = $_POST['owner_email'] ?? '';
    $ownerPhone = $_POST['owner_phone'] ?? '';
    $specialRequirements = $_POST['special_requirements'] ?? '';
    
    // Basic validation
    if (empty($petType) || empty($planType) || empty($startDate) || 
        empty($petName) || empty($ownerName) || 
        empty($ownerEmail) || empty($ownerPhone)) {
        $errorMsg = "Please fill all required fields.";
    } else {
        // In a real application, you would:
        // 1. Check availability
        // 2. Insert booking into database
        // 3. Calculate total price
        // 4. Process payment
        // 5. Send confirmation email
        
        // For now, just simulate success
        $successMsg = "Your daycare booking for $petName has been confirmed starting from $startDate!";
        
        // Reset form
        $petType = $planType = $startDate = $petName = 
        $petBreed = $petAge = $petWeight = $ownerName = $ownerEmail = 
        $ownerPhone = $specialRequirements = '';
        $additionalServicesList = [];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Daycare Booking - The Canine & Feline Co.</title>
    <link href="https://fonts.googleapis.com/css?family=Montserrat:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    
    <style>
        .plan-card {
            border: 1px solid #eee;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }
        
        .plan-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        
        .plan-card.selected {
            border-color: #00bd56;
            background-color: rgba(0, 189, 86, 0.05);
        }
        
        .plan-card.selected::before {
            content: '✓';
            position: absolute;
            top: 10px;
            right: 10px;
            width: 25px;
            height: 25px;
            background-color: #00bd56;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        
        .plan-price {
            color: #00bd56;
            font-weight: bold;
            font-size: 1.25rem;
        }
        
        .booking-form {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 30px rgba(0,0,0,0.05);
            padding: 30px;
        }
        
        .pet-type-selector {
            display: flex;
            margin-bottom: 20px;
        }
        
        .pet-type-option {
            flex: 1;
            text-align: center;
            padding: 15px;
            border: 2px solid #eee;
            border-radius: 10px;
            cursor: pointer;
            margin: 0 10px;
            transition: all 0.3s ease;
        }
        
        .pet-type-option:hover {
            transform: translateY(-5px);
        }
        
        .pet-type-option.selected {
            border-color: #00bd56;
            background-color: rgba(0, 189, 86, 0.05);
        }
        
        .pet-type-option i {
            font-size: 40px;
            display: block;
            margin-bottom: 10px;
            color: #555;
        }
        
        .pet-type-option.selected i {
            color: #00bd56;
        }
        
        .section-heading {
            position: relative;
            padding-bottom: 15px;
            margin-bottom: 30px;
            font-weight: 600;
        }
        
        .section-heading::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 3px;
            background-color: #00bd56;
        }
        
        .booking-btn {
            background-color: #00bd56;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 5px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .booking-btn:hover {
            background-color: #009945;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .hero-section {
            background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('images/daycare-bg.jpg');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 100px 0;
            margin-bottom: 50px;
            text-align: center;
        }
        
        .hero-section h1 {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 20px;
        }
        
        .hero-section p {
            font-size: 1.2rem;
            max-width: 700px;
            margin: 0 auto;
        }
        
        /* Additional service checkbox styling */
        .additional-service {
            border: 1px solid #eee;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .additional-service:hover {
            background-color: #f8f9fa;
        }
        
        .additional-service.selected {
            border-color: #00bd56;
            background-color: rgba(0, 189, 86, 0.05);
        }
        
        .additional-service .form-check-input {
            margin-right: 10px;
        }
        
        .additional-service-price {
            color: #00bd56;
            font-weight: 600;
        }
        
        /* Summary card */
        .booking-summary {
            position: sticky;
            top: 20px;
            border-radius: 8px;
            overflow: hidden;
        }
        
        .summary-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .summary-item:last-child {
            border-bottom: none;
        }
        
        .summary-total {
            font-size: 1.2rem;
            font-weight: 700;
            color: #00bd56;
            border-top: 2px solid #eee;
            padding-top: 15px;
            margin-top: 15px;
        }
        
        .plan-type-toggle {
            margin-bottom: 30px;
        }
        
        .plan-type-toggle .btn {
            width: 50%;
            padding: 10px;
        }
        
        #custom-duration-section .card {
            border: 1px solid #00bd56;
            border-radius: 8px;
        }
        
        #custom-duration-section .alert {
            margin-bottom: 0;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container">
        <a class="navbar-brand" href="index.html" style="font-weight: 400;">
          <span class="flaticon-pawprint-1 mr-2"></span>The Canine & Feline Co.
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="fa fa-bars"></span> Menu
        </button>
        <div class="collapse navbar-collapse" id="ftco-nav">
          <div class="navbar-nav ml-auto">
            <div class="nav-item">
              <a href="hhh2.php" class="nav-link">
                <i class="fa-solid fa-house mr-2"></i> Home
              </a>
            </div>
          </div>
        </div>
      </div>
    </nav>
    <!-- END nav -->
    
    <!-- Hero Section -->
    <div class="hero-section">
        <div class="container">
            <h1>Pet Daycare Services</h1>
            <p>Leave your furry friend in our trusted care while you're away. We provide a loving, safe, and fun environment.</p>
        </div>
    </div>
    
    <div class="container mb-5">
        <?php if (!empty($errorMsg)): ?>
            <div class="alert alert-danger mb-4"><?php echo $errorMsg; ?></div>
        <?php endif; ?>
        
        <?php if (!empty($successMsg)): ?>
            <div class="alert alert-success mb-4"><?php echo $successMsg; ?></div>
        <?php endif; ?>
        
        <div class="row">
            <!-- Left Column: Booking Form -->
            <div class="col-lg-8">
                <div class="booking-form">
                    <h2 class="section-heading">Book Pet Daycare</h2>
                    
                    <form method="POST" id="booking-form">
                        <!-- Step 1: Select Pet Type -->
                        <div class="booking-step" id="step-1">
                            <h4 class="mb-4">Step 1: Tell us about your pet</h4>
                            <div class="pet-type-selector">
                                <div class="pet-type-option" data-pet-type="dog">
                                    <i class="fas fa-dog"></i>
                                    <h5>Dog</h5>
                                </div>
                                <div class="pet-type-option" data-pet-type="cat">
                                    <i class="fas fa-cat"></i>
                                    <h5>Cat</h5>
                                </div>
                            </div>
                            <input type="hidden" name="pet_type" id="pet-type-input">
                            
                            <div class="form-group">
                                <label for="pet_name">Pet's Name*</label>
                                <input type="text" class="form-control" id="pet_name" name="pet_name" required>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="pet_breed">Breed</label>
                                        <input type="text" class="form-control" id="pet_breed" name="pet_breed">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="pet_age">Age</label>
                                        <input type="text" class="form-control" id="pet_age" name="pet_age">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="pet_weight">Weight (kg)</label>
                                        <input type="number" class="form-control" id="pet_weight" name="pet_weight">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Step 2: Select Daycare Plan -->
                        <div class="booking-step mt-5" id="step-2">
                            <h4 class="mb-4">Step 2: Choose a daycare plan</h4>
                            
                            <div class="plan-type-toggle mb-4">
                                <div class="btn-group btn-group-toggle w-100" data-toggle="buttons">
                                    <label class="btn btn-outline-success active">
                                        <input type="radio" name="plan_option" id="option-standard" value="standard" checked> Standard Plans
                                    </label>
                                    <label class="btn btn-outline-success">
                                        <input type="radio" name="plan_option" id="option-custom" value="custom"> Custom Duration
                                    </label>
                                </div>
                            </div>
                            
                            <!-- Standard Plans Section -->
                            <div id="standard-plans-section">
                                <!-- Dog Plans (Initially Visible) -->
                                <div id="dog-plans" class="plans-container">
                                    <div class="row">
                                        <?php foreach ($daycarePlans['dog'] as $id => $plan): ?>
                                            <div class="col-md-6">
                                                <div class="plan-card" data-plan="<?php echo $id; ?>">
                                                    <h5><?php echo $plan['name']; ?></h5>
                                                    <p class="plan-price">₹<?php echo $plan['price']; ?></p>
                                                    <?php if (isset($plan['hours'])): ?>
                                                        <p class="text-muted mb-0"><?php echo $plan['hours']; ?> hours of supervised care</p>
                                                    <?php else: ?>
                                                        <p class="text-muted mb-0"><?php echo $plan['days']; ?> days of supervised care</p>
                                                    <?php endif; ?>
                                                    <ul class="small text-muted mt-2">
                                                        <li>Supervised playtime</li>
                                                        <li>Feeding service</li>
                                                        <li>Regular bathroom breaks</li>
                                                        <?php if ($id == 'weekly' || $id == 'monthly'): ?>
                                                            <li>Health monitoring</li>
                                                            <li>Daily activity report</li>
                                                        <?php endif; ?>
                                                    </ul>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                
                                <!-- Cat Plans -->
                                <div id="cat-plans" class="plans-container" style="display: none;">
                                    <div class="row">
                                        <?php foreach ($daycarePlans['cat'] as $id => $plan): ?>
                                            <div class="col-md-6">
                                                <div class="plan-card" data-plan="<?php echo $id; ?>">
                                                    <h5><?php echo $plan['name']; ?></h5>
                                                    <p class="plan-price">₹<?php echo $plan['price']; ?></p>
                                                    <?php if (isset($plan['hours'])): ?>
                                                        <p class="text-muted mb-0"><?php echo $plan['hours']; ?> hours of supervised care</p>
                                                    <?php else: ?>
                                                        <p class="text-muted mb-0"><?php echo $plan['days']; ?> days of supervised care</p>
                                                    <?php endif; ?>
                                                    <ul class="small text-muted mt-2">
                                                        <li>Comfortable resting spaces</li>
                                                        <li>Feeding service</li>
                                                        <li>Clean litter maintenance</li>
                                                        <?php if ($id == 'weekly' || $id == 'monthly'): ?>
                                                            <li>Health monitoring</li>
                                                            <li>Daily activity report</li>
                                                        <?php endif; ?>
                                                    </ul>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Custom Duration Section (Initially Hidden) -->
                            <div id="custom-duration-section" style="display: none;">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label>Duration Type</label>
                                            <div class="btn-group btn-group-toggle w-100 mb-3" data-toggle="buttons">
                                                <label class="btn btn-outline-primary active">
                                                    <input type="radio" name="duration_type" id="duration-hours" value="hours" checked> Hours
                                                </label>
                                                <label class="btn btn-outline-primary">
                                                    <input type="radio" name="duration_type" id="duration-days" value="days"> Days
                                                </label>
                                            </div>
                                        </div>
                                        
                                        <div id="hours-selector" class="form-group">
                                            <label for="custom_hours">Number of Hours</label>
                                            <input type="number" class="form-control" id="custom_hours" name="custom_hours" min="1" max="12" value="4">
                                            <small class="form-text text-muted">Rate: ₹<span id="hourly-rate">80</span> per hour</small>
                                        </div>
                                        
                                        <div id="days-selector" class="form-group" style="display: none;">
                                            <label for="custom_days">Number of Days</label>
                                            <input type="number" class="form-control" id="custom_days" name="custom_days" min="1" max="30" value="1">
                                            <small class="form-text text-muted">Rate: ₹<span id="daily-rate">600</span> per day</small>
                                        </div>
                                        
                                        <div class="form-group" id="end-date-group" style="display: none;">
                                            <label for="end_date">End Date</label>
                                            <input type="date" class="form-control" id="end_date" name="end_date" readonly>
                                        </div>
                                        
                                        <div class="alert alert-info">
                                            <div class="d-flex justify-content-between">
                                                <strong>Estimated Total:</strong>
                                                <span>₹<span id="custom-price">320</span></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <input type="hidden" name="plan_type" id="plan-type-input">
                            <input type="hidden" name="custom_price" id="hidden-custom-price" value="0">
                        </div>
                        
                        <!-- Step 3: Select Date & Additional Services -->
                        <div class="booking-step mt-5" id="step-3">
                            <h4 class="mb-4">Step 3: Choose start date</h4>
                            
                            <div class="form-group">
                                <label for="start_date">Start Date*</label>
                                <input type="date" class="form-control" id="start_date" name="start_date" min="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            
                            <h4 class="mb-4 mt-5">Additional Services</h4>
                            <p class="text-muted mb-4">Enhance your pet's daycare experience with these optional services</p>
                            
                            <div class="row">
                                <?php foreach ($additionalServices as $id => $service): ?>
                                    <div class="col-md-6">
                                        <div class="additional-service">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="additional_services[]" id="service_<?php echo $id; ?>" value="<?php echo $id; ?>">
                                                <label class="form-check-label" for="service_<?php echo $id; ?>">
                                                    <div><?php echo $service['name']; ?></div>
                                                    <div class="additional-service-price">₹<?php echo $service['price']; ?></div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <!-- Step 4: Your Information -->
                        <div class="booking-step mt-5" id="step-4">
                            <h4 class="mb-4">Step 4: Your contact information</h4>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="owner_name">Your Name*</label>
                                        <input type="text" class="form-control" id="owner_name" name="owner_name" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="owner_email">Email Address*</label>
                                        <input type="email" class="form-control" id="owner_email" name="owner_email" required>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="owner_phone">Phone Number*</label>
                                <input type="tel" class="form-control" id="owner_phone" name="owner_phone" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="special_requirements">Special Requirements or Instructions</label>
                                <textarea class="form-control" id="special_requirements" name="special_requirements" rows="3" placeholder="Tell us about any special needs, dietary requirements, or medications"></textarea>
                            </div>
                        </div>
                        
                        <div class="text-center mt-5">
                            <button type="submit" name="book_daycare" class="booking-btn">
                                <i class="fas fa-calendar-check mr-2"></i> Book Daycare
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Right Column: Booking Summary -->
            <div class="col-lg-4">
                <div class="card booking-summary mb-4" id="booking-summary" style="display: none;">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0"><i class="fas fa-clipboard-check mr-2"></i> Booking Summary</h5>
                    </div>
                    <div class="card-body">
                        <div class="summary-item" id="summary-pet">
                            <span>Pet:</span>
                            <span>Not selected</span>
                        </div>
                        <div class="summary-item" id="summary-plan">
                            <span>Plan:</span>
                            <span>Not selected</span>
                        </div>
                        <div class="summary-item" id="summary-date">
                            <span>Start Date:</span>
                            <span>Not selected</span>
                        </div>
                        <div id="summary-additional-services">
                            <!-- Additional services will be listed here -->
                        </div>
                        <div class="summary-total d-flex justify-content-between">
                            <span>Total:</span>
                            <span>₹<span id="total-price">0</span></span>
                        </div>
                    </div>
                </div>
                
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-info-circle mr-2"></i> Our Daycare Services</h5>
                    </div>
                    <div class="card-body">
                        <p>Our pet daycare services provide:</p>
                        <ul class="mb-0">
                            <li>Safe, supervised play areas</li>
                            <li>Socialization with other friendly pets</li>
                            <li>Regular feeding and bathroom breaks</li>
                            <li>Comfortable resting areas</li>
                            <li>Trained staff on premises at all times</li>
                            <li>Climate-controlled environment</li>
                        </ul>
                    </div>
                </div>
                
                <div class="card mb-4">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="mb-0"><i class="fas fa-exclamation-triangle mr-2"></i> Important Information</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Before your pet's stay:</strong></p>
                        <ul class="mb-0">
                            <li>All pets must be up-to-date on vaccinations</li>
                            <li>Please bring your pet's food to maintain their diet</li>
                            <li>Any medications should be clearly labeled</li>
                            <li>Bring a familiar toy or blanket for comfort</li>
                            <li>Cancellations must be made 24 hours in advance</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer -->
    <footer class="bg-dark text-white py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>The Canine & Feline Co.</h5>
                    <p>Providing premium care for your pets since 2010. Our professional team is dedicated to keeping your pets healthy and happy.</p>
                </div>
                <div class="col-md-4">
                    <h5>Contact Us</h5>
                    <p><i class="fas fa-map-marker-alt mr-2"></i> 123 Pet Street, Bangalore, India</p>
                    <p><i class="fas fa-phone mr-2"></i> +91 98765 43210</p>
                    <p><i class="fas fa-envelope mr-2"></i> info@caninefeline.com</p>
                </div>
                <div class="col-md-4">
                    <h5>Opening Hours</h5>
                    <p>Monday - Friday: 7:00 AM - 7:00 PM</p>
                    <p>Saturday: 8:00 AM - 6:00 PM</p>
                    <p>Sunday: 9:00 AM - 5:00 PM</p>
                </div>
            </div>
            <hr class="bg-light">
            <div class="text-center">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> The Canine & Feline Co. All rights reserved.</p>
            </div>
        </div>
    </footer>
    
    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <script>
    $(document).ready(function() {
        // Set dog as default pet type on page load
        $('#pet-type-input').val('dog');
        $('.pet-type-option[data-pet-type="dog"]').addClass('selected');
        
        // Pet Type Selection
        $('.pet-type-option').click(function() {
            $('.pet-type-option').removeClass('selected');
            $(this).addClass('selected');
            
            const petType = $(this).data('pet-type');
            $('#pet-type-input').val(petType);
            
            // Show corresponding plans
            $('.plans-container').hide();
            $('#' + petType + '-plans').show();
            
            // Reset plan selection
            $('.plan-card').removeClass('selected');
            $('#plan-type-input').val('');
            
            updateSummary();
        });
        
        // Plan Selection
        $('.plan-card').click(function() {
            $('.plan-card').removeClass('selected');
            $(this).addClass('selected');
            
            const planType = $(this).data('plan');
            $('#plan-type-input').val(planType);
            
            updateSummary();
        });
        
        // Date selection
        $('#start_date').change(function() {
            updateSummary();
        });
        
        // Additional services selection
        $('.additional-service').click(function() {
            const checkbox = $(this).find('input[type="checkbox"]');
            checkbox.prop('checked', !checkbox.prop('checked'));
            $(this).toggleClass('selected', checkbox.prop('checked'));
            
            updateSummary();
        });
        
        // Checkbox click handling
        $('.form-check-input').click(function(e) {
            e.stopPropagation();
            $(this).closest('.additional-service').toggleClass('selected', this.checked);
            
            updateSummary();
        });
        
        // Update booking summary
        function updateSummary() {
            let totalPrice = 0;
            let showSummary = false;
            
            // Pet info
            const petType = $('#pet-type-input').val();
            const petName = $('#pet_name').val();
            if (petType && petName) {
                showSummary = true;
                $('#summary-pet').html(`
                    <span>Pet:</span>
                    <span>${petName} (${petType.charAt(0).toUpperCase() + petType.slice(1)})</span>
                `);
            }
            
            // Plan info
            const planType = $('#plan-type-input').val();
            if (planType && petType) {
                const planInfo = <?php echo json_encode($daycarePlans); ?>[petType][planType];
                $('#summary-plan').html(`
                    <span>Plan:</span>
                    <span>${planInfo.name} (₹${planInfo.price})</span>
                `);
                totalPrice += planInfo.price;
            }
            
            // Date info
            const startDate = $('#start_date').val();
            if (startDate) {
                const formattedDate = new Date(startDate).toLocaleDateString('en-IN', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                });
                $('#summary-date').html(`
                    <span>Start Date:</span>
                    <span>${formattedDate}</span>
                `);
            }
            
            // Additional services
            const additionalServicesData = <?php echo json_encode($additionalServices); ?>;
            let additionalServicesHtml = '';
            
            $('input[name="additional_services[]"]:checked').each(function() {
                const serviceId = $(this).val();
                const serviceInfo = additionalServicesData[serviceId];
                
                additionalServicesHtml += `
                    <div class="summary-item">
                        <span>${serviceInfo.name}:</span>
                        <span>₹${serviceInfo.price}</span>
                    </div>
                `;
                
                totalPrice += serviceInfo.price;
            });
            
            $('#summary-additional-services').html(additionalServicesHtml);
            
            // Update total price
            $('#total-price').text(totalPrice);
            
            // Show/hide summary
            $('#booking-summary').toggle(showSummary);
        }
        
        // Form Validation
        $('#booking-form').submit(function(e) {
            let isValid = true;
            
            // Check pet type
            if (!$('#pet-type-input').val()) {
                alert('Please select a pet type (Dog or Cat)');
                isValid = false;
            }
            
            // Check daycare plan
            if (!$('#plan-type-input').val()) {
                alert('Please select a daycare plan');
                isValid = false;
            }
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    });
    </script>
</body>
</html> 