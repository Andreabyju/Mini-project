<?php
session_start();
require_once "../connect.php";

// Check if the user is logged in and has admin privileges
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

// Handle form submission for adding a new service
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_service'])) {
    $service_name = $_POST['service_name'];
    $service_description = $_POST['service_description'];
    $service_price = $_POST['service_price'];

    // Validate inputs
    $errors = [];
    if (empty($service_name)) {
        $errors['service_name'] = 'Service name is required';
    }
    if (empty($service_description)) {
        $errors['service_description'] = 'Service description is required';
    }
    if (empty($service_price) || !is_numeric($service_price)) {
        $errors['service_price'] = 'Valid service price is required';
    }

    // If no errors, insert the service into the database
    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO services (name, description, price) VALUES (?, ?, ?)");
        $stmt->execute([$service_name, $service_description, $service_price]);
        $success_message = "Service added successfully!";
    }
}

// Fetch existing services for display
$stmt = $conn->query("SELECT * FROM services");
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Services - The Canine & Feline Co.</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 30px;
        }
        .form-group label {
            font-weight: 500;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mb-4">Manage Grooming and Spa Services</h1>

        <!-- Success Message -->
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>

        <!-- Error Messages -->
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Form to Add New Service -->
        <form method="POST" action="">
            <div class="form-group">
                <label for="service_name">Service Name</label>
                <input type="text" name="service_name" id="service_name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="service_description">Service Description</label>
                <textarea name="service_description" id="service_description" class="form-control" required></textarea>
            </div>
            <div class="form-group">
                <label for="service_price">Service Price (INR)</label>
                <input type="number" name="service_price" id="service_price" class="form-control" required>
            </div>
            <button type="submit" name="add_service" class="btn btn-primary">Add Service</button>
        </form>

        <h2 class="mt-5">Existing Services</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Price (INR)</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($services as $service): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($service['id']); ?></td>
                        <td><?php echo htmlspecialchars($service['name']); ?></td>
                        <td><?php echo htmlspecialchars($service['description']); ?></td>
                        <td>₹<?php echo number_format($service['price'], 2); ?></td>
                        <td>
                            <a href="edit_service.php?id=<?php echo $service['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="delete_service.php?id=<?php echo $service['id']; ?>" class="btn btn-danger btn-sm">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html> 