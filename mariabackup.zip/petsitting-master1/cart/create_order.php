<?php
session_start();
require_once "../connect.php";

// Set headers to handle AJAX request
header('Content-Type: application/json');

// Verify if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
    exit;
}

// Check if amount is provided
if (!isset($_POST['amount']) || empty($_POST['amount'])) {
    echo json_encode(['status' => 'error', 'message' => 'Amount is required']);
    exit;
}

// Get customer data
$formData = isset($_POST['formData']) ? json_decode($_POST['formData'], true) : [];
$amount = floatval($_POST['amount']) * 100; // Convert to paise

// Include Razorpay SDK
require 'vendor/autoload.php'; // Make sure Razorpay SDK is installed via Composer

// Razorpay API credentials
$keyId = 'rzp_test_CzoNYGf1d0sXyX'; // Your Razorpay Key ID
$keySecret = 'YOUR_RAZORPAY_SECRET_KEY'; // Replace with your actual secret key

try {
    // Initialize Razorpay API
    $api = new Razorpay\Api\Api($keyId, $keySecret);
    
    // Create order data
    $orderData = [
        'receipt' => 'order_' . time(),
        'amount' => $amount,
        'currency' => 'INR',
        'notes' => [
            'name' => isset($formData['first_name']) ? $formData['first_name'] . ' ' . $formData['last_name'] : '',
            'email' => isset($formData['email']) ? $formData['email'] : '',
            'phone' => isset($formData['phone']) ? $formData['phone'] : '',
        ]
    ];
    
    // Create order
    $razorpayOrder = $api->order->create($orderData);
    
    // Store order details in session for later verification
    $_SESSION['razorpay_order_id'] = $razorpayOrder['id'];
    $_SESSION['checkout_form_data'] = $formData;
    
    // Return success response
    echo json_encode([
        'status' => 'success',
        'order_id' => $razorpayOrder['id'],
        'amount' => $razorpayOrder['amount'],
        'currency' => $razorpayOrder['currency']
    ]);
} catch (Exception $e) {
    // Return error response
    echo json_encode([
        'status' => 'error',
        'message' => 'Error creating order: ' . $e->getMessage()
    ]);
    exit;
}
?> 