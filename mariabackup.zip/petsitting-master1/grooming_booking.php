<?php
session_start();
require_once "connect.php";

// Initialize variables
$services = [
    'dog' => [
        'basic_bath' => ['name' => 'Basic Bath & Brush', 'price' => 599],
        'premium_groom' => ['name' => 'Premium Full Groom', 'price' => 999],
        'deluxe_spa' => ['name' => 'Deluxe Spa Package', 'price' => 1499],
        'nail_trim' => ['name' => 'Nail Trimming', 'price' => 249],
        'teeth_clean' => ['name' => 'Teeth Cleaning', 'price' => 349],
    ],
    'cat' => [
        'basic_bath' => ['name' => 'Basic Bath & Brush', 'price' => 499],
        'premium_groom' => ['name' => 'Premium Full Groom', 'price' => 899],
        'deluxe_spa' => ['name' => 'Deluxe Spa Package', 'price' => 1299],
        'nail_trim' => ['name' => 'Nail Trimming', 'price' => 199],
        'teeth_clean' => ['name' => 'Teeth Cleaning', 'price' => 299],
    ]
];

$timeSlots = [
    '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
    '12:00', '12:30', '13:00', '13:30', '14:00', '14:30',
    '15:00', '15:30', '16:00', '16:30', '17:00', '17:30'
];

$errorMsg = '';
$successMsg = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_appointment'])) {
    // Validate inputs
    $petType = $_POST['pet_type'] ?? '';
    $serviceType = $_POST['service_type'] ?? '';
    $bookingDate = $_POST['booking_date'] ?? '';
    $bookingTime = $_POST['booking_time'] ?? '';
    $petName = $_POST['pet_name'] ?? '';
    $petBreed = $_POST['pet_breed'] ?? '';
    $petAge = $_POST['pet_age'] ?? '';
    $petWeight = $_POST['pet_weight'] ?? '';
    $ownerName = $_POST['owner_name'] ?? '';
    $ownerEmail = $_POST['owner_email'] ?? '';
    $ownerPhone = $_POST['owner_phone'] ?? '';
    $specialInstructions = $_POST['special_instructions'] ?? '';
    
    // Basic validation
    if (empty($petType) || empty($serviceType) || empty($bookingDate) || 
        empty($bookingTime) || empty($petName) || empty($ownerName) || 
        empty($ownerEmail) || empty($ownerPhone)) {
        $errorMsg = "Please fill all required fields.";
    } else {
        // In a real application, you would:
        // 1. Check if the slot is available
        // 2. Insert booking into database
        // 3. Send confirmation email
        
        // For now, just simulate success
        $successMsg = "Your grooming appointment has been booked successfully! We'll see you and $petName on $bookingDate at $bookingTime.";
        
        // Reset form
        $petType = $serviceType = $bookingDate = $bookingTime = $petName = 
        $petBreed = $petAge = $petWeight = $ownerName = $ownerEmail = 
        $ownerPhone = $specialInstructions = '';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grooming & Spa Booking - The Canine & Feline Co.</title>
    <link href="https://fonts.googleapis.com/css?family=Montserrat:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    
    <style>
        .service-card {
            border: 1px solid #eee;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }
        
        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        
        .service-card.selected {
            border-color: #00bd56;
            background-color: rgba(0, 189, 86, 0.05);
        }
        
        .service-card.selected::before {
            content: '✓';
            position: absolute;
            top: 10px;
            right: 10px;
            width: 25px;
            height: 25px;
            background-color: #00bd56;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        
        .service-price {
            color: #00bd56;
            font-weight: bold;
            font-size: 1.25rem;
        }
        
        .booking-form {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 30px rgba(0,0,0,0.05);
            padding: 30px;
        }
        
        .appointment-date-input {
            position: relative;
        }
        
        .appointment-date-input i {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #aaa;
        }
        
        .time-slot {
            display: inline-block;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin: 5px;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .time-slot:hover {
            background-color: #f8f9fa;
        }
        
        .time-slot.selected {
            background-color: #00bd56;
            color: white;
            border-color: #00bd56;
        }
        
        .pet-type-selector {
            display: flex;
            margin-bottom: 20px;
        }
        
        .pet-type-option {
            flex: 1;
            text-align: center;
            padding: 15px;
            border: 2px solid #eee;
            border-radius: 10px;
            cursor: pointer;
            margin: 0 10px;
            transition: all 0.3s ease;
        }
        
        .pet-type-option:hover {
            transform: translateY(-5px);
        }
        
        .pet-type-option.selected {
            border-color: #00bd56;
            background-color: rgba(0, 189, 86, 0.05);
        }
        
        .pet-type-option i {
            font-size: 40px;
            display: block;
            margin-bottom: 10px;
            color: #555;
        }
        
        .pet-type-option.selected i {
            color: #00bd56;
        }
        
        .section-heading {
            position: relative;
            padding-bottom: 15px;
            margin-bottom: 30px;
            font-weight: 600;
        }
        
        .section-heading::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 3px;
            background-color: #00bd56;
        }
        
        .booking-btn {
            background-color: #00bd56;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 5px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .booking-btn:hover {
            background-color: #009945;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .hero-section {
            background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('images/grooming-bg.jpg');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 100px 0;
            margin-bottom: 50px;
            text-align: center;
        }
        
        .hero-section h1 {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 20px;
        }
        
        .hero-section p {
            font-size: 1.2rem;
            max-width: 700px;
            margin: 0 auto;
        }
        
        /* Added style for total price display */
        .total-price-container {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-top: 20px;
            border: 1px solid #e9ecef;
        }
        
        .total-price-value {
            font-size: 1.5rem;
            font-weight: bold;
            color: #00bd56;
        }
        
        #selected-services-list {
            max-height: 200px;
            overflow-y: auto;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container">
        <a class="navbar-brand" href="index.html" style="font-weight: 400;">
          <span class="flaticon-pawprint-1 mr-2"></span>The Canine & Feline Co.
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="fa fa-bars"></span> Menu
        </button>
        <div class="collapse navbar-collapse" id="ftco-nav">
          <div class="navbar-nav ml-auto">
            <div class="nav-item">
              <a href="hhh2.php" class="nav-link">
                <i class="fa-solid fa-house mr-2"></i> Home
              </a>
            </div>
          </div>
        </div>
      </div>
    </nav>
    <!-- END nav -->
    
    <!-- Hero Section -->
    <div class="hero-section">
        <div class="container">
            <h1>Pet Grooming & Spa Services</h1>
            <p>Treat your furry friend to a day of pampering and care with our professional grooming services</p>
        </div>
    </div>
    
    <div class="container mb-5">
        <?php if (!empty($errorMsg)): ?>
            <div class="alert alert-danger mb-4"><?php echo $errorMsg; ?></div>
        <?php endif; ?>
        
        <?php if (!empty($successMsg)): ?>
            <div class="alert alert-success mb-4"><?php echo $successMsg; ?></div>
        <?php endif; ?>
        
        <div class="row">
            <!-- Left Column: Booking Form -->
            <div class="col-lg-8">
                <div class="booking-form">
                    <h2 class="section-heading">Book a Grooming Appointment</h2>
                    
                    <form method="POST" id="booking-form">
                        <!-- Step 1: Select Pet Type -->
                        <div class="booking-step" id="step-1">
                            <h4 class="mb-4">Step 1: Tell us about your pet</h4>
                            <div class="pet-type-selector">
                                <div class="pet-type-option" data-pet-type="dog">
                                    <i class="fas fa-dog"></i>
                                    <h5>Dog</h5>
                                </div>
                                <div class="pet-type-option" data-pet-type="cat">
                                    <i class="fas fa-cat"></i>
                                    <h5>Cat</h5>
                                </div>
                            </div>
                            <input type="hidden" name="pet_type" id="pet-type-input">
                            
                            <div class="form-group">
                                <label for="pet_name">Pet's Name*</label>
                                <input type="text" class="form-control" id="pet_name" name="pet_name" required>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="pet_breed">Breed</label>
                                        <input type="text" class="form-control" id="pet_breed" name="pet_breed">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="pet_age">Age</label>
                                        <input type="text" class="form-control" id="pet_age" name="pet_age">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="pet_weight">Weight (kg)</label>
                                        <input type="number" class="form-control" id="pet_weight" name="pet_weight">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Step 2: Select Service -->
                        <div class="booking-step mt-5" id="step-2">
                            <h4 class="mb-4">Step 2: Choose service(s)</h4>
                            <p class="text-muted">Select one or more services for your pet</p>
                            
                            <!-- Dog Services (Initially Visible) -->
                            <div id="dog-services" class="services-container">
                                <div class="row">
                                    <?php foreach ($services['dog'] as $id => $service): ?>
                                        <div class="col-md-6">
                                            <div class="service-card multi-select" data-service="<?php echo $id; ?>">
                                                <h5><?php echo $service['name']; ?></h5>
                                                <p class="service-price">₹<?php echo $service['price']; ?></p>
                                                <p class="text-muted mb-0">For dogs of all sizes</p>
                                                <?php if ($id === 'basic_bath'): ?>
                                                    <p class="small text-muted">Includes bath, blow dry, ear cleaning, nail trim</p>
                                                <?php elseif ($id === 'premium_groom'): ?>
                                                    <p class="small text-muted">Includes bath, blow dry, haircut, ear cleaning, nail trim</p>
                                                <?php elseif ($id === 'deluxe_spa'): ?>
                                                    <p class="small text-muted">Includes premium groom plus teeth cleaning, special shampoo treatment, paw care</p>
                                                <?php elseif ($id === 'nail_trim'): ?>
                                                    <p class="small text-muted">Quick nail trim and filing service</p>
                                                <?php elseif ($id === 'teeth_clean'): ?>
                                                    <p class="small text-muted">Professional teeth cleaning service</p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            
                            <!-- Cat Services -->
                            <div id="cat-services" class="services-container" style="display: none;">
                                <div class="row">
                                    <?php foreach ($services['cat'] as $id => $service): ?>
                                        <div class="col-md-6">
                                            <div class="service-card multi-select" data-service="<?php echo $id; ?>">
                                                <h5><?php echo $service['name']; ?></h5>
                                                <p class="service-price">₹<?php echo $service['price']; ?></p>
                                                <p class="text-muted mb-0">For cats of all sizes</p>
                                                <?php if ($id === 'basic_bath'): ?>
                                                    <p class="small text-muted">Includes gentle bath, blow dry, ear cleaning, nail trim</p>
                                                <?php elseif ($id === 'premium_groom'): ?>
                                                    <p class="small text-muted">Includes bath, blow dry, coat trim, ear cleaning, nail trim</p>
                                                <?php elseif ($id === 'deluxe_spa'): ?>
                                                    <p class="small text-muted">Includes premium groom plus teeth cleaning, special shampoo treatment, paw care</p>
                                                <?php elseif ($id === 'nail_trim'): ?>
                                                    <p class="small text-muted">Quick nail trim and filing service</p>
                                                <?php elseif ($id === 'teeth_clean'): ?>
                                                    <p class="small text-muted">Professional teeth cleaning service</p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            
                            <!-- Changed to array input for multiple service selection -->
                            <input type="hidden" name="service_type[]" id="service-type-input" value="">
                        </div>
                        
                        <!-- Step 3: Select Date & Time -->
                        <div class="booking-step mt-5" id="step-3">
                            <h4 class="mb-4">Step 3: Choose date and time</h4>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="booking_date">Appointment Date*</label>
                                        <div class="appointment-date-input">
                                            <input type="date" class="form-control" id="booking_date" name="booking_date" min="<?php echo date('Y-m-d'); ?>" required>
                                            <i class="fas fa-calendar"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="booking_time">Appointment Time*</label>
                                        <select class="form-control" id="booking_time" name="booking_time" required>
                                            <option value="">Select a time</option>
                                            <?php foreach ($timeSlots as $slot): ?>
                                                <option value="<?php echo $slot; ?>"><?php echo $slot; ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Step 4: Your Information -->
                        <div class="booking-step mt-5" id="step-4">
                            <h4 class="mb-4">Step 4: Your contact information</h4>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="owner_name">Your Name*</label>
                                        <input type="text" class="form-control" id="owner_name" name="owner_name" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="owner_email">Email Address*</label>
                                        <input type="email" class="form-control" id="owner_email" name="owner_email" required>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="owner_phone">Phone Number*</label>
                                <input type="tel" class="form-control" id="owner_phone" name="owner_phone" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="special_instructions">Special Instructions or Requests</label>
                                <textarea class="form-control" id="special_instructions" name="special_instructions" rows="3"></textarea>
                            </div>
                        </div>
                        
                        <div class="text-center mt-5">
                            <button type="submit" name="book_appointment" class="booking-btn">
                                <i class="fas fa-calendar-check mr-2"></i> Book Appointment
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Right Column: Information -->
            <div class="col-lg-4">
                <!-- Selected Services Summary Box (New Position) -->
                <div class="card mb-4" id="service-total" style="display: none;">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0"><i class="fas fa-shopping-cart mr-2"></i> Selected Services (<span id="selected-count">0</span>)</h5>
                    </div>
                    <div class="card-body">
                        <div id="selected-services-list" class="mb-3">
                            <!-- Selected services will be listed here dynamically -->
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Total:</h5>
                            <h4 class="text-success mb-0">₹<span id="total-price">0</span></h4>
                        </div>
                    </div>
                </div>
                
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-info-circle mr-2"></i> Our Grooming Services</h5>
                    </div>
                    <div class="card-body">
                        <p>Our professional grooming services include:</p>
                        <ul class="mb-0">
                            <li>Bath with premium shampoo</li>
                            <li>Blow dry and brush out</li>
                            <li>Nail trimming and filing</li>
                            <li>Ear cleaning</li>
                            <li>Teeth brushing (premium packages)</li>
                            <li>Styling and haircut (premium packages)</li>
                            <li>Aromatherapy (deluxe packages)</li>
                        </ul>
                    </div>
                </div>
                
                <div class="card mb-4">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0"><i class="fas fa-paw mr-2"></i> Why Choose Us</h5>
                    </div>
                    <div class="card-body">
                        <ul class="mb-0">
                            <li>Certified professional groomers</li>
                            <li>Cage-free, stress-free environment</li>
                            <li>Premium, pet-safe products</li>
                            <li>Individual attention to each pet</li>
                            <li>Clean, sanitized equipment</li>
                            <li>Special care for seniors and puppies/kittens</li>
                        </ul>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="mb-0"><i class="fas fa-exclamation-triangle mr-2"></i> Important Information</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Before Your Appointment:</strong></p>
                        <ul class="mb-0">
                            <li>Please ensure your pet's vaccinations are up to date</li>
                            <li>Arrive 10 minutes before your appointment time</li>
                            <li>Cancellations should be made at least 24 hours in advance</li>
                            <li>Please inform us of any health issues or allergies your pet may have</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer -->
    <footer class="bg-dark text-white py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>The Canine & Feline Co.</h5>
                    <p>Providing premium care for your pets since 2010. Our professional team is dedicated to keeping your pets healthy and happy.</p>
                </div>
                <div class="col-md-4">
                    <h5>Contact Us</h5>
                    <p><i class="fas fa-map-marker-alt mr-2"></i> 123 Pet Street, Bangalore, India</p>
                    <p><i class="fas fa-phone mr-2"></i> +91 98765 43210</p>
                    <p><i class="fas fa-envelope mr-2"></i> info@caninefeline.com</p>
                </div>
                <div class="col-md-4">
                    <h5>Opening Hours</h5>
                    <p>Monday - Friday: 9:00 AM - 6:00 PM</p>
                    <p>Saturday: 9:00 AM - 5:00 PM</p>
                    <p>Sunday: Closed</p>
                </div>
            </div>
            <hr class="bg-light">
            <div class="text-center">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> The Canine & Feline Co. All rights reserved.</p>
            </div>
        </div>
    </footer>
    
    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <script>
    $(document).ready(function() {
        // Set dog as default pet type on page load
        $('#pet-type-input').val('dog');
        $('.pet-type-option[data-pet-type="dog"]').addClass('selected');
        
        // Pet Type Selection
        $('.pet-type-option').click(function() {
            $('.pet-type-option').removeClass('selected');
            $(this).addClass('selected');
            
            const petType = $(this).data('pet-type');
            $('#pet-type-input').val(petType);
            
            // Show corresponding services
            $('.services-container').hide();
            $('#' + petType + '-services').show();
            
            // Reset service selections when changing pet type
            $('.service-card').removeClass('selected');
            updateSelectedServices();
        });
        
        // Multiple Service Selection - KEY CHANGE HERE
        $('.service-card').click(function() {
            // TOGGLE class instead of removing from all
            $(this).toggleClass('selected');
            updateSelectedServices();
        });
        
        // Update selected services and total
        function updateSelectedServices() {
            const selectedServices = [];
            let totalPrice = 0;
            const petType = $('#pet-type-input').val();
            const servicesList = $('#selected-services-list');
            servicesList.empty();
            
            // Get all selected services
            $('.service-card.selected').each(function() {
                const serviceId = $(this).data('service');
                selectedServices.push(serviceId);
                
                // Add to visible list and calculate total
                const serviceName = $(this).find('h5').text();
                const servicePrice = parseInt($(this).find('.service-price').text().replace('₹', ''));
                totalPrice += servicePrice;
                
                // Add each service to the list
                servicesList.append(`<div class="mb-1">• ${serviceName} - ₹${servicePrice}</div>`);
            });
            
            // Update the count
            $('#selected-count').text(selectedServices.length);
            
            // Update the hidden input with comma-separated service IDs
            $('#service-type-input').val(selectedServices.join(','));
            
            // Update the total price display
            $('#total-price').text(totalPrice);
            if (selectedServices.length > 0) {
                $('#service-total').show();
            } else {
                $('#service-total').hide();
            }
        }
        
        // Form Validation
        $('#booking-form').submit(function(e) {
            let isValid = true;
            
            // Check pet type
            if (!$('#pet-type-input').val()) {
                alert('Please select a pet type (Dog or Cat)');
                isValid = false;
            }
            
            // Check if at least one service is selected
            if ($('.service-card.selected').length === 0) {
                alert('Please select at least one service');
                isValid = false;
            }
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    });
    </script>
</body>
</html> 